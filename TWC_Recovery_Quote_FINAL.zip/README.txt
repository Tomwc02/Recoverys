TWC RECOVERY QUOTE — FINAL

This is a mobile web app/PWA.

To publish it with GitHub Pages:
1. Create a public GitHub repository, e.g. twc-recovery-quote.
2. Upload ALL files from this folder to the repository root.
3. Settings -> Pages -> Deploy from branch -> main -> / (root) -> Save.
4. Open the generated HTTPS address in Safari on your iPhone.
5. Safari Share -> Add to Home Screen.

The app stores pricing settings locally on the device. Default pricing:
£150 callout, first 13 miles included, £3 per additional mile, 20% VAT.

Vehicle cost per mile defaults from the revised spreadsheet:
Porsche Cayenne 4.2 V8: £1.382335955/mile
Volkswagen Touareg V6 3.0: £1.285550241/mile

Customer pricing uses one-way miles. Profitability uses actual total miles driven; the app defaults actual miles to twice the one-way distance until you manually change them.
